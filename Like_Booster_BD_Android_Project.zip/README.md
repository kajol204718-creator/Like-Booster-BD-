# Like Booster BD 🚀

Bilingual Flutter Android starter with Firebase Email/Password authentication.

## Firebase setup required
1. In Firebase Console, register an Android app with package name `com.likeboosterbd.app`.
2. Download `google-services.json` and place it at `android/app/google-services.json`.
3. In Firebase Authentication > Sign-in method, enable Email/Password.
4. Do not publish Firestore in test mode. Add restrictive security rules before storing user or post data.

The app uses email/password authentication. A Gmail address can be used as the email, but this is not Google Sign-In (OAuth).

## Build
GitHub Actions workflow generates the Android folder, adds Google Services Gradle plugin, and builds a release APK after the Firebase config file is present.
