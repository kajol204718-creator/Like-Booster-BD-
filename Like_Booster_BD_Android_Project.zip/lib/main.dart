import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
  } catch (_) {
    // Firebase config must be added to android/app/google-services.json.
  }
  runApp(const LikeBoosterApp());
}

class LikeBoosterApp extends StatefulWidget {
  const LikeBoosterApp({super.key});
  @override
  State<LikeBoosterApp> createState() => _LikeBoosterAppState();
}

class _LikeBoosterAppState extends State<LikeBoosterApp> {
  bool english = false;
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1877F2)), useMaterial3: true),
    home: AuthPage(english: english, toggleLanguage: () => setState(() => english = !english)),
  );
}

class AuthPage extends StatefulWidget {
  final bool english;
  final VoidCallback toggleLanguage;
  const AuthPage({super.key, required this.english, required this.toggleLanguage});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool register = false, busy = false;
  String? error;
  String t(String bn, String en) => widget.english ? en : bn;

  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      if (Firebase.apps.isEmpty) {
        throw FirebaseException(plugin: 'firebase_core', message: 'Firebase setup missing. Add google-services.json and enable Email/Password sign-in in Firebase Console.');
      }
      if (register) {
        await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.text.trim(), password: password.text);
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: password.text);
      }
    } on FirebaseAuthException catch (e) {
      setState(() => error = e.message ?? e.code);
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() { email.dispose(); password.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Like Booster BD 🚀', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF1877F2), foregroundColor: Colors.white,
        actions: [TextButton(onPressed: widget.toggleLanguage, child: const Text('BN / EN', style: TextStyle(color: Colors.white)))],
      ),
      body: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            final user = snapshot.data!;
            return Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(
              mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.rocket_launch, size: 58, color: Color(0xFF1877F2)),
                const SizedBox(height: 12),
                Text(t('স্বাগতম!', 'Welcome!'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                Text(user.email ?? ''),
                const SizedBox(height: 16),
                FilledButton(onPressed: () => FirebaseAuth.instance.signOut(), child: Text(t('লগআউট', 'Log out'))),
              ],
            )));
          }
          return ListView(padding: const EdgeInsets.all(22), children: [
            const SizedBox(height: 22),
            const Icon(Icons.rocket_launch_rounded, size: 72, color: Color(0xFF1877F2)),
            const SizedBox(height: 10),
            const Text('LIKE BOOSTER BD 🚀', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
            Text(t('Gmail দিয়ে অ্যাকাউন্ট খুলুন অথবা লগইন করুন', 'Register or sign in with your email'), textAlign: TextAlign.center),
            const SizedBox(height: 28),
            TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: InputDecoration(labelText: t('Gmail / Email', 'Gmail / Email'), prefixIcon: const Icon(Icons.email), border: const OutlineInputBorder())),
            const SizedBox(height: 14),
            TextField(controller: password, obscureText: true, decoration: InputDecoration(labelText: t('পাসওয়ার্ড', 'Password'), prefixIcon: const Icon(Icons.lock), border: const OutlineInputBorder())),
            const SizedBox(height: 18),
            FilledButton(onPressed: busy ? null : submit, child: Text(busy ? t('অপেক্ষা করুন...', 'Please wait...') : register ? t('অ্যাকাউন্ট তৈরি করুন', 'Create account') : t('লগইন', 'Sign in'))),
            TextButton(onPressed: () => setState(() { register = !register; error = null; }), child: Text(register ? t('আগে অ্যাকাউন্ট আছে? লগইন', 'Already registered? Sign in') : t('নতুন অ্যাকাউন্ট খুলুন', 'Create a new account'))),
            if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: Colors.red))),
            const SizedBox(height: 20),
            Text(t('নোট: লগইন চালাতে Firebase Android কনফিগারেশন প্রয়োজন।', 'Note: Firebase Android configuration is required for sign-in.'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
          ]);
        },
      ),
    );
  }
}
